﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mercadinho.Prateleira.Domain
{
    public enum UnidadeMedidaEnum
    {
        grama = 1,
        kilograma = 2,
        peca = 3,
        pacote = 4,
        caixa = 5,
        mililitro = 6,
        litro = 7
    }
}
