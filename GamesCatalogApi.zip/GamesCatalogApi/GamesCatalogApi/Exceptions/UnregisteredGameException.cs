﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GamesCatalogApi.Exceptions {
  public class UnregisteredGameException: Exception {
    public UnregisteredGameException():base("It was not possible to find any games with these statuses. Try using other names.") { }
  }
}
