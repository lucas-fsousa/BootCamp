﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GamesCatalogApi.Exceptions {
  public class GameReRegisterException: Exception {

    public GameReRegisterException():base("There is already a registered game with this name for this producer.Please try again using other names.") { }
  }
}
