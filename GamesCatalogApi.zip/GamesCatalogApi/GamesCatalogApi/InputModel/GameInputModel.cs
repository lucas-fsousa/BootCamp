﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GamesCatalogApi.InputModel {
  public class GameInputModel {
    [Required]
    [StringLength(100, MinimumLength = 3, ErrorMessage = "The game name must contain from 3 to 100 characters.")]
    public string Name { get; set; }

    [Required]
    [StringLength(100, MinimumLength = 3, ErrorMessage = "The producer name must contain from 3 to 100 characters.")]
    public string Producer { get; set; }

    [Required]
    [Range(1, 1000, ErrorMessage = "The price must be greater than $0,00 and may reach a maximum of $1000,00")]
    public decimal Price { get; set; }
  }
}
