﻿using GamesCatalogApi.Entities.Games;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GamesCatalogApi.InputModel.Repositories.Games {
  public interface IGameRepository: IDisposable {

    public Task<List<Game>> GetGames(int page, int quantity);

    public Task<Game> GetGame(int id);

    public Task<Game> GetGame(string name, string producer);

    public Task<Game> InsertGame(Game game);

    public Task GameUpdate(Game game);

    public Task DeleteGame(int id);
  }
}
