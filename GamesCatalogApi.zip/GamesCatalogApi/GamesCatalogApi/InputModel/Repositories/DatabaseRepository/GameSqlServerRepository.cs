﻿using GamesCatalogApi.Entities.Games;
using GamesCatalogApi.InputModel.Repositories.Games;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace GamesCatalogApi.InputModel.Repositories.DatabaseRepository {
  public class GameSqlServerRepository : IGameRepository {
    private readonly SqlConnection sqlConnection;

    public GameSqlServerRepository(IConfiguration configuration) {
      sqlConnection = new SqlConnection(configuration.GetConnectionString("Default"));
    }

    public async Task DeleteGame(int id) {
      var sqlQuery = $"DELETE from games WHERE id = {id}";
      await sqlConnection.OpenAsync();
      SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
      command.ExecuteNonQuery();
      await sqlConnection.CloseAsync();
    }

    public void Dispose() {
      sqlConnection?.Close();
      sqlConnection?.Dispose();
    }

    public async Task GameUpdate(Game game) {
      var sqlQuery = $"UPDATE games set name = '{game.Name}', producer = '{game.Producer}', price = '{game.Price.ToString().Replace(",", ".")}' WHERE id = '{game.Id}'";
      await sqlConnection.OpenAsync();
      SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
      command.ExecuteNonQuery();
      await sqlConnection.CloseAsync();
    }

    public async Task<Game> GetGame(int id) {
      Game game = null;
      var sqlQuery = $"SELECT * FROM games WHERE id = {id}";
      await sqlConnection.OpenAsync();
      SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
      SqlDataReader reader = await command.ExecuteReaderAsync();

      while(reader.Read()) {
        game = new Game {
          Id = Convert.ToInt32(reader["Id"]),
          Name = reader["Name"].ToString(),
          Producer = reader["Producer"].ToString(),
          Price = Convert.ToDecimal(reader["Price"])
        };
      }

      await sqlConnection.CloseAsync();
      return game;
    }

    public async Task<Game> GetGame(string name, string producer) {
      var game = new Game();
      var sqlQuery = $"SELECT * FROM games WHERE name = '{name}' and producer = '{producer}'";
      await sqlConnection.OpenAsync();
      SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
      SqlDataReader reader = await command.ExecuteReaderAsync();

      while(reader.Read()) {
        game.Id = Convert.ToInt32(reader["Id"]);
        game.Name = reader["Name"].ToString();
        game.Producer = reader["Producer"].ToString();
        game.Price = Convert.ToDecimal(reader["Price"]);
      }

      await sqlConnection.CloseAsync();
      return game;
    }

    public async Task<List<Game>> GetGames(int page, int quantity) {
      var games = new List<Game>();
      var sqlQuery = $"SELECT * FROM games ORDER BY id OFFSET {((page - 1) * quantity)} ROWS FETCH NEXT {quantity} rows only";
      await sqlConnection.OpenAsync();
      SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
      SqlDataReader reader = await command.ExecuteReaderAsync();

      while(reader.Read()) {
        games.Add(new Game {
          Id = Convert.ToInt32(reader["Id"]),
          Name = reader["Name"].ToString(),
          Producer = reader["Producer"].ToString(),
          Price = Convert.ToDecimal(reader["Price"])
        });
      }

      await sqlConnection.CloseAsync();
      return games;
    }

    public async Task<Game> InsertGame(Game game) {
      var sqlQuery = $"INSERT INTO games(name, producer, price) VALUES ('{game.Name}', '{game.Producer}', '{game.Price.ToString().Replace(",", ".")}')";
      await sqlConnection.OpenAsync();
      SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
      command.ExecuteNonQuery();
      await sqlConnection.CloseAsync();
      return null;
    }
  }
}
