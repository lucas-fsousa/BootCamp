﻿using GamesCatalogApi.Entities.Games;
using GamesCatalogApi.Exceptions;
using GamesCatalogApi.InputModel;
using GamesCatalogApi.InputModel.Repositories.Games;
using GamesCatalogApi.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GamesCatalogApi.Services.Games {
  public class GameServices: IGameServices {

    private readonly IGameRepository _gameRepository;

    public GameServices(IGameRepository gameRepository) {
      _gameRepository = gameRepository;
    }

    public async Task<List<GameViewModel>> GetGames(int page, int quantity) {
      var games = await _gameRepository.GetGames(page, quantity);
      return games.Select(game => new GameViewModel {
        Id = game.Id,
        Name = game.Name,
        Producer = game.Producer,
        Price = game.Price
      }).ToList();
    }

    public async Task<GameViewModel> GetGame(int id) {
      var game = await _gameRepository.GetGame(id);
      if(game == null) {
        return null;
      } else {
        return new GameViewModel {
          Id = game.Id,
          Name = game.Name,
          Producer = game.Producer,
          Price = game.Price
        };
      }

    }

    public async Task<GameViewModel> InsertGame(GameInputModel gameInputModel) {
      var entity = await _gameRepository.GetGame(gameInputModel.Name, gameInputModel.Producer);
      if(entity.Id != 0) {
        throw new GameReRegisterException();
      }

      var gameInsert = new Game {
        Name = gameInputModel.Name,
        Producer = gameInputModel.Producer,
        Price = gameInputModel.Price
      };
      await _gameRepository.InsertGame(gameInsert);

      return new GameViewModel {
        Name = gameInputModel.Name,
        Producer = gameInputModel.Producer,
        Price = gameInputModel.Price
      };

    }

    public async Task GameUpdate(int id, GameInputModel gameInputModel) {
      var entity = await _gameRepository.GetGame(id);
      if(entity == null) {
        throw new UnregisteredGameException();
      }
      entity.Name = gameInputModel.Name;
      entity.Producer = gameInputModel.Producer;
      entity.Price = gameInputModel.Price;
      await _gameRepository.GameUpdate(entity);
    }

    public async Task GameUpdate(int id, decimal price) {
      var entity = await _gameRepository.GetGame(id);
      if(entity == null) {
        throw new UnregisteredGameException();
      }
      entity.Price = price;
      await _gameRepository.GameUpdate(entity);
    }

    public async Task DeleteGame(int id) {
      var game = await _gameRepository.GetGame(id);
      if(game == null) {
        throw new UnregisteredGameException();
      }
      await _gameRepository.DeleteGame(id);
    }

    public void Dispose() {
      _gameRepository?.Dispose();
    }

  }
}
