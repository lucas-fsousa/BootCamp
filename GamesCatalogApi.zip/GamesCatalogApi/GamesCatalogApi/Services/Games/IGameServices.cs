﻿using GamesCatalogApi.InputModel;
using GamesCatalogApi.InputModel.Repositories.Games;
using GamesCatalogApi.ViewModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GamesCatalogApi.Services.Games {
  public interface IGameServices: IDisposable {
    public Task<List<GameViewModel>> GetGames(int page, int quantity);

    public Task<GameViewModel> GetGame(int id);

    public Task<GameViewModel> InsertGame(GameInputModel game);

    public Task GameUpdate(int id, GameInputModel game); // HTTP put

    public Task GameUpdate(int id, decimal price); // HTTP patch

    public Task DeleteGame(int id);
  }
}
