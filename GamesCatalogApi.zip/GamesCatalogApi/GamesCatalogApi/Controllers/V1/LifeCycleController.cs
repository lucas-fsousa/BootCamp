﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GamesCatalogApi.Controllers.V1 {

  [Route("api/v1/[controller]")]
  [ApiController]
  public class LifeCycleController : ControllerBase {
    private readonly ISingletonExamble _singleton1Example;
    private readonly ISingletonExamble _singleton2Example;

    private readonly IScopedExample _scoped1Example;
    private readonly IScopedExample _scoped2Example;

    private readonly ITransientExamble _transient1Example;
    private readonly ITransientExamble _Transient2Example;

    public LifeCycleController(
      ISingletonExamble singletonExamble1,
      ISingletonExamble singletonExamble2,
      IScopedExample scopedExample1,
      IScopedExample scopedExample2,
      ITransientExamble transientExamble1,
      ITransientExamble transientExamble2) {

      _singleton1Example = singletonExamble1;
      _singleton2Example = singletonExamble2;

      _scoped1Example = scopedExample1;
      _scoped2Example = scopedExample2;

      _transient1Example = transientExamble1;
      _Transient2Example = transientExamble2;

    }

    [HttpGet]
    public Task<string> Get() {
      StringBuilder strBuilder = new StringBuilder();
      strBuilder.AppendLine($"Singleton 1: {_singleton1Example.Id}");
      strBuilder.AppendLine($"Singleton 2: {_singleton2Example.Id}");
      strBuilder.AppendLine();
      strBuilder.AppendLine($"Scoped 1: {_scoped1Example.Id}");
      strBuilder.AppendLine($"Scoped 2: {_scoped2Example.Id}");
      strBuilder.AppendLine();
      strBuilder.AppendLine($"Transient 1: {_transient1Example.Id}");
      strBuilder.AppendLine($"Transient 2: {_Transient2Example.Id}");

      return Task.FromResult(strBuilder.ToString());
    }


    public interface IGeneralExample {
      public int Id { get; }
    }

    public interface ISingletonExamble: IGeneralExample { }
    public interface IScopedExample: IGeneralExample { }
    public interface ITransientExamble: IGeneralExample { }

    public class LifeCycleExample : ISingletonExamble, IScopedExample, ITransientExamble {
      Random rand = new Random();
      private readonly int _id;

      public LifeCycleExample() {
        _id = rand.Next();
      }
      public int Id => _id;
    }
  }
}
