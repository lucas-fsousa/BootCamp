﻿using GamesCatalogApi.Exceptions;
using GamesCatalogApi.InputModel;
using GamesCatalogApi.Services.Games;
using GamesCatalogApi.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GamesCatalogApi.Controllers.V1 {
  [Route("api/V1/[controller]")]
  [ApiController]
  public class GameController : ControllerBase {

    private readonly IGameServices _gameServices;

    public GameController(IGameServices gameServices) {
      _gameServices = gameServices;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<GameViewModel>>> GetObject([FromQuery, Range(1, int.MaxValue)] int page = 1, [FromQuery, Range(1, 50)] int quantity = 5) {
      
      var games = await _gameServices.GetGames(page, quantity);
      if(games.Count() == 0) {
        return NoContent();
      } else {
        return Ok(games);
      }
    }

    [HttpGet("{gameId:int}")]
    public async Task<ActionResult<GameViewModel>> GetObject([FromRoute] int gameId) {
      
      var game = await _gameServices.GetGame(gameId);
      if(game == null) {
        return NoContent();
      }else {
        return Ok(game);
      }
    }

    [HttpPost]
    public async Task<ActionResult<GameViewModel>> InsertGame([FromBody]GameInputModel gameInputModel) {
      try {
        var game = await _gameServices.InsertGame(gameInputModel);
        return Ok(game);
      } catch(GameReRegisterException ex) {
        return UnprocessableEntity("There is already a game with this name registered for this producer. | " + ex);
      }
    }

    [HttpPut("{gameId:int}")]
    public async Task<ActionResult> UpdateGame([FromRoute]int gameId, [FromBody]GameInputModel gameInputModel) {
      try {
        await _gameServices.GameUpdate(gameId, gameInputModel);
        return Ok();
      } catch(UnregisteredGameException ex) {
        return NotFound("This game does not exist. Please enter a valid entry. | " + ex);
      }
    }

    [HttpPatch("{gameId:int}/price/{price:decimal}")]
    public async Task<ActionResult> UpdateGame([FromRoute]int gameId, [FromRoute]decimal price) {
      try {
        await _gameServices.GameUpdate(gameId, price);
        return Ok();
      } catch(UnregisteredGameException ex) {
        return NotFound("This game does not exist. Please enter a valid entry. | " + ex);
      }
    }

    [HttpDelete("{gameId:int}")]
    public async Task<ActionResult> DeleteGame(int gameId) {
      try {
        await _gameServices.DeleteGame(gameId);
        return Ok();
      } catch(UnregisteredGameException ex) {
        return NotFound("This game does not exist. Please enter a valid entry. | " + ex);
      }
    }

  }
}
