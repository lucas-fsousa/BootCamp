create table games(
Id int identity not null primary key(Id),
Name varchar(60) not null,
Producer varchar(60) not null,
Price decimal(18,2));


select * from games;
