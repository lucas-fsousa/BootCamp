﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankTransferProject.Enum {
  public enum AccountType {
    Cpf = 0, // physical person
    Cnpj = 1 // corporate / business entity
  }
}
