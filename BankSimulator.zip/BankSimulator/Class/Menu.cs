﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankTransferProject.Class {
  public static class Menu {
    public static string showMenu(params string[] itensMenu) {
      Console.WriteLine("\n\n|----------- SELECT AN ITEM FROM THE MENU -----------|\n");
      for(int i = 0; i < itensMenu.Length; i++) {
        Console.WriteLine($" [{i + 1}] - {itensMenu[i]}");
      }
      Console.WriteLine(" [X] - EXIT");
      Console.WriteLine("\n\n|----------------------------------------------------|");
      Console.Write(" SELECTED >> ");
      return Console.ReadLine().ToUpper();
    }

    public static string showMenu() {
      Console.WriteLine("\n\n|----------- SELECT AN ITEM FROM THE MENU -----------|\n");
      Console.WriteLine(" [X] - EXIT");
      Console.WriteLine("\n\n|----------------------------------------------------|");
      Console.Write(" SELECTED >> ");
      return Console.ReadLine().ToUpper();
    }

  }
}
