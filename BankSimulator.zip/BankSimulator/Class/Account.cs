﻿using BankTransferProject.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankTransferProject.Class {
  public class Account {
    private int accountNumber;
    private string name;
    private AccountType accountType;
    private double funds;
    private double credit;

    public Account(string name, AccountType accountType, double funds, double credit, int accountNumber) {
      this.name = name;
      this.accountType = accountType;
      this.funds = funds;
      this.credit = credit;
      this.accountNumber = accountNumber;
    }
    public Account() { }

    // Getters and Setters
    public string Name { get => name; set => name = value; }
    public AccountType AccountType { get => accountType; set => accountType = value; }
    public double Funds { get => funds; set => funds = value; }
    public double Credit { get => credit; set => credit = value; }
    public int AccountNumber { get => accountNumber; set => accountNumber = value; }

    // Other methods
    public bool Withdraw(double value) {

      if(this.funds < value) {// Validate funds
        if(this.funds + this.credit < value) {
          Console.WriteLine("insufficient funds!");
          return false;
        } else {      
          this.credit += this.funds - value;
          this.funds = 0;
          return true;
        } 
      } else {
        this.funds -= value;
        Console.WriteLine($"You debited R${value} - Current Fund R${this.funds.ToString(".00")}");
        return true;
      }

    }

    public void Deposit(double value) {
      bool ok = false;
      if(value < 0.0) {
        Console.WriteLine("It is not possible to deposit negative amounts. Please enter a valid value.");
      } else {
        this.funds += value;
        Console.WriteLine($"You have received a deposit of R${value} and your current funds is {this.funds.ToString(".00")}");
      }
    }

    public void Transfer(double value, Account destinationAccount) {
      if(this.Withdraw(value)) {
        Console.WriteLine($"You transferred R${value} to {destinationAccount.Name}! Currenty funds R${this.funds.ToString(".00")}");
        destinationAccount.Deposit(value);
      } else {
        Console.WriteLine("Sorry! An error occurred while transferring values.");
      }
    }

    public void accountState() {
      string state = $" | Account Number: {this.accountNumber} | Name: {this.name}  | Account Type:  {this.accountType} | Funds: {this.funds.ToString(".00")} | Credit: {this.credit} |";

      int length = state.Count(); // returns the count of continuous characters of a string

      for(int i = 0; i < length; i++) {
        Console.Write("_");
        if(i == length - 1) {
          Console.WriteLine("\n\n" + state);
          for(int j = i; j >= 0; j--) {
            Console.Write("_");
          }
        }
      }
      Console.WriteLine("\n");
    }

  }
}
