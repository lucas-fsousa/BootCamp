﻿using BankTransferProject.Class;
using BankTransferProject.Enum;
using System;
using System.Linq;
using System.Collections.Generic;

namespace BankTransferProject {
  class Program {
    public static List<Account> list = new List<Account>();
    static void Main(string[] args) {
      Account account1 = new Account("Paulo José zézin da silva ribeiro", Enum.AccountType.Cpf, 11050.44, 5000, 12345);
      Account account2 = new Account("Maria manicure e pedicure State home", Enum.AccountType.Cnpj, 500, 300, 112233);
      list.Add(account1);
      list.Add(account2);
      string option;
      do {
        start();
        option = Menu.showMenu("List Accounts", "New Account", "Deposit", "Transfer", "Withdraw");
        switch(option) {
          case "1":
            ListAccounts();
            break;
          case "2":
            NewAccount();
            break;
          case "3":
            Deposit();
            break;
          case "4":
            Transfer();
            break;
          case "5":
            Withdraw();
            break;
          case "X":
            break;
          default:
            Console.WriteLine("Invalid option!\n\n");
            break;
        }
      } while(option != "X");
    }

    private static void Withdraw() {
      int accountNumber;
      bool ok = false;
      string resp;
      Console.WriteLine("******** WITHDRAW *********");
      do {
        Console.Write("Enter the account number: ");
        accountNumber = Int32.Parse(Console.ReadLine());

        //Valite account number
        foreach(var item in list) {
          if(item.AccountNumber == accountNumber) {
            ok = true;
          }
        }

        if(!ok) {
          Console.Write("\nAccount does not exist. Do you want to try again?[S/N]: ");
          resp = Console.ReadLine().ToUpper();
          if(resp.Equals("N")) {
            return;
          }
        } else {
          break;
        }
      } while(true);

      Console.Write("\nAmount to be withdrawn R$");
      double amount = double.Parse(Console.ReadLine());

      foreach(var item in list) {
        if(item.AccountNumber == accountNumber) {
          item.Withdraw(amount);
        }
      }
    }

    private static void Transfer() {
      int accountNumberOrigin, accountNumberDestiny;
      int cc = 0;
      string resp;
      Console.WriteLine("********** Transfer ***********");
      do {
        Console.Write("Enter orign account number: ");
        accountNumberOrigin = Int32.Parse(Console.ReadLine());
        Console.Write("Enter destination account number: ");
        accountNumberDestiny = Int32.Parse(Console.ReadLine());

        //Valite account number
        foreach(var item in list) {
          if(item.AccountNumber == accountNumberOrigin) {
            cc++;
          }
          if(item.AccountNumber == accountNumberDestiny) {
            cc++;
          }
        }

        if(cc != 2) {
          Console.Write("\nAccount does not exist. Do you want to try again?[S/N]: ");
          resp = Console.ReadLine().ToUpper();
          if(resp.Equals("N")) {
            return;
          }
        } else {
          break;
        }
      } while(true);

      Console.Write("\nAmount to be transfer R$");
      double amount = double.Parse(Console.ReadLine());

      foreach(var destiny in list) {
        if(destiny.AccountNumber == accountNumberDestiny) {
          foreach(var origin in list) {
            if(origin.AccountNumber == accountNumberOrigin) {
              origin.Transfer(amount, destiny);
              break;
            }
          }
        }
      }
    }

    private static void Deposit() {
      int accountNumber;
      bool ok = false;
      string resp;
      Console.WriteLine("********** DEPOSIT ***********");
      do {
        Console.Write("Enter the account number: ");
        accountNumber = Int32.Parse(Console.ReadLine());

        //Valite account number
        foreach(var item in list) {
          if(item.AccountNumber == accountNumber) {
            ok = true;
          }
        }

        if(!ok) {
          Console.Write("\nAccount does not exist. Do you want to try again?[S/N]: ");
          resp = Console.ReadLine().ToUpper();
          if(resp.Equals("N")) {
            return;
          }
        } else {
          break;
        }
      } while(true);

      Console.Write("\nAmount to be deposit R$");
      double amount = double.Parse(Console.ReadLine());

      foreach(var item in list) {
        if(item.AccountNumber == accountNumber) {
          item.Deposit(amount);
        }
      }
    }

    private static void ListAccounts() {
      if(list.Count < 1) {
        Console.WriteLine("It was not possible to find any registered account.");
      } else {
        foreach(var item in list) {
          item.accountState();
        }
      }
    }
    
    private static void start() {
      Console.Write("Press any key to continue...");
      Console.ReadKey();
      Console.Clear();
    }

    private static void NewAccount() {
      Account acc = new Account();
      Console.WriteLine(" ********** NEW ACCOUNT *********** ");
      do {
        Console.Write("Account Type [0 -> PF] <|> [1-> PJ]: ");
        var temp = int.Parse(Console.ReadLine().Trim());
        if(temp >= 0 && temp <= 1) {
          acc.AccountType = (AccountType)(temp);
          break;
        } else {
          Console.WriteLine("Invalid option!\n");
        } 
      } while(true);
      Console.Write("User name: ");
      acc.Name = Console.ReadLine().Trim();
      Console.Write("Start credit R$");
      acc.Credit = double.Parse(Console.ReadLine().Replace(".",",").Trim());
      Console.Write("Start funds R$");
      acc.Funds = double.Parse(Console.ReadLine().Replace(".", ",").Trim());
      Random rnd = new Random();
      while(true) {
        var x = rnd.Next(99999);
        int cont = 0;
        foreach(var item in list) {
          if(item.AccountNumber == x) {
            cont++;
          }
        }
        if(cont == 0) {
          acc.AccountNumber = x;
          break;
        }
      }
      Console.WriteLine($"Account number generated: {acc.AccountNumber}");
      list.Add(acc);
    }
  }
}
