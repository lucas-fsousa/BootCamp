﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DecolaTechMentoring.Domain {
  public abstract class AccountBank {

    public AccountBank(Customer customer) {
      Customer = customer ?? throw new Exception("Woops... Customer not found!");
      State = AccountStatus.Opening;

      Random rnd = new Random();
      AccountNumber = rnd.Next(5000, 99999999);
      VerifyingDigit = rnd.Next(0, 9);
    }

    public int AccountNumber { get; init; }
    public int VerifyingDigit { get; init; }
    public decimal Funds { get; protected set; }
    public string Password { get; private set; }
    public DateTime? AccountStarted { get; private set; }
    public DateTime? AccountClosed { get; private set; }
    public AccountStatus State { get; private set; }
    public Customer Customer { get; init; }
   
    
    public void Open(string password) {
      SetPassword(password);
      State = AccountStatus.Opened;
      AccountStarted = DateTime.Now;
    }
    private void SetPassword(string password) {
      password = password.StringValidate();
      if(!Regex.IsMatch(password, @"^(?=.*?[a-z])(?=.*?[0-9]).{8,}$")) {
        throw new Exception("Invalid Password");
      } else {
        Password = password;
      }
    }

    public virtual void GetFunds(decimal value, string password) {
      if(password  == Password && value > 0) {
        if(Funds > value) {
          Funds -= value;
        } else {
          throw new Exception("insufficient funds");
        }
      } else {
        throw new Exception("Invalid password");
      }
    }

    public void Deposit(decimal value) {
      if(value > 0) {
        Funds += value;
      }
    }

  }
}
