﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecolaTechMentoring.Domain {
  public static class Validation {
    public static string StringValidate(this string text) {
      string message = "Required field for registration. Make sure you fill in properly!";
      return string.IsNullOrWhiteSpace(text) ? throw new Exception(message) : text;
    }
  }
}
