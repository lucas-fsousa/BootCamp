﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecolaTechMentoring.Domain {
  public class AccountPJ: AccountBank {
    public AccountPJ(Customer customer, decimal limit): base(customer) {
      MaintenanceFee = 0.05M;
      Limit = limit;
    }

    
    public override void GetFunds(decimal value, string password) {
      if(password == Password && value > 0) {
        if((Funds+Limit) > value) {
          Funds -= value;
        } else {
          throw new Exception("insufficient funds");
        }
      } else {
        throw new Exception("Invalid password");
      }
    }
    public decimal Limit { get; private set; }
    public decimal MaintenanceFee { get; private set; }
  }
}
