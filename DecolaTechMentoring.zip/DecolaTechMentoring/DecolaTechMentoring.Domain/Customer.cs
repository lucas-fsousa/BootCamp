﻿using System;

namespace DecolaTechMentoring.Domain {
  public class Customer {

    public Customer(string name, string cpf, string rg, Adress adress) {
      string message = "Required field for registration. Make sure you fill in properly!";
      Name = name.StringValidate();
      Cpf = cpf.StringValidate();
      Rg = rg.StringValidate();
      Adress = adress ?? throw new Exception(message);
    }

    public string Name { get; private set; }
    public string Cpf { get; private set; }
    public string Rg { get; private set; }
    public Adress Adress { get; private set; }
  }




  public class Adress {
    public string City { get; private set; }
    public string PostalCode { get; private set; }
    public string State { get; private set; }
    public string PublicPlace { get; private set; }

    public Adress(string city, string postalCode, string state, string publicPlace) {
      City = city.StringValidate();
      PostalCode = postalCode.StringValidate();
      State = state.StringValidate();
      PublicPlace = publicPlace.StringValidate();
    }

  }
}
