﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecolaTechMentoring.Domain {
  public class AccountPF: AccountBank {
    public AccountPF(Customer customer):base(customer) {
      MonthlyIncomePercentage = 0.003M;
    }

    public decimal MonthlyIncomePercentage { get; private set; }
  }
}
