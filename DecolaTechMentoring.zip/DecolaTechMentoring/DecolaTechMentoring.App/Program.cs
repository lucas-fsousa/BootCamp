﻿using DecolaTechMentoring.Domain;
using System;

namespace DecolaTechMentoring.App {
  class Program {
    static void Main(string[] args) {

      try {
        Adress adress = new Adress("Goiania", "1234-50", "GO", "Avenida 12");
        Customer customer = new Customer("Alonso", "01010101", "131411", adress);
        AccountPF account = new AccountPF(customer);

        Console.WriteLine($"Account: {account.AccountNumber} | {account.State}");
        account.Open("abcd1234");
        Console.WriteLine($"Account: {account.AccountNumber} | {account.State}");
        account.GetFunds(10, "abcd1234");
      } catch(Exception ex) {
        Console.WriteLine(ex.Message);
      }
    }
  }
}
