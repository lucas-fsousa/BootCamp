using Series.APP.Enum;
using System;

namespace Series.APP.Classes {
  public class Serie: Molde {
    private Genero Genero { get; set; }
    private string Titulo { get; set; }
    private string Descricao { get; set; }
    private int Ano { get; set; }
    private bool Excluido { get; set; }

    public Serie(int id, Genero genero, string titulo, string descricao, int ano) {
      this.Id = id;
      this.Genero = genero;
      this.Titulo = titulo;
      this.Descricao = descricao;
      this.Ano = ano;
      this.Excluido = false;
    }

    public int RetornaAno() {
      return this.Ano;
    }

    public Genero RetornaGenero() {
      return this.Genero;
    }

    public string RetornaDescricao() {
      return this.Descricao;
    }

    public override string ToString() {
      string retorno = "";
      retorno += "g�nero: " + this.Genero + Environment.NewLine;
      retorno += "titulo: " + this.Titulo + Environment.NewLine;
      retorno += "descri��o: " + this.Descricao + Environment.NewLine;
      retorno += "ano de inicio: " + this.Ano + Environment.NewLine;
      retorno +=  "excluido: " + this.Excluido + Environment.NewLine;
      return retorno;
    }

    public string retornaTItulo() {
      return this.Titulo;
    }

    public int retornaId() {
      return this.Id;
    }

    public bool retornaExcluido() {
      return this.Excluido;
    }
    public void Excluir() {
      this.Excluido = true;
    }

  }
}