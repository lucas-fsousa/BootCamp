namespace Series.APP.Classes {
  public abstract class Molde {
    public int Id { get; protected set; }
  }
}