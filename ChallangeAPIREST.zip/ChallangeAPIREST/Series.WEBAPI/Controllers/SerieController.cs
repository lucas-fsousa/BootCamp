﻿using Microsoft.AspNetCore.Mvc;
using Series.APP.Classes;
using Series.APP.Enum;
using Series.APP.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Series.WEBAPI.Controllers {
  [Route("api/v1/[controller]")]
  [ApiController]
  public class SerieController : ControllerBase {
    private readonly IRepositorio<Serie> _repositorio;
    public SerieController(IRepositorio<Serie> repositorio) {
      _repositorio = repositorio;
    }


    // GET: api/<SerieController>
    [HttpGet, Route("GetAll")]
    public IActionResult Get() {
      var resultado = _repositorio.Lista().Select(x => new SerieModel(x));
      return Ok(resultado);
    }

    // GET api/<SerieController>/5
    [HttpGet, Route("Get/{id}")]
    public IActionResult Get(int id) {
      return Ok(new SerieModel(_repositorio.Lista().FirstOrDefault(x => x.Id == id)));
    }

    // POST api/<SerieController>
    [HttpPost, Route("Post")]
    public IActionResult Post([FromBody] SerieModel model) {
      model.Id = _repositorio.ProximoId();
      Serie serie = model.ToSerie();
      
      _repositorio.Insere(serie);
      return Created("", serie);
    }

    // PUT api/<SerieController>/5
    [HttpPut, Route("Put/{id}")]
    public IActionResult Put(int id, [FromBody] SerieModel model) {
      _repositorio.Atualiza(id, model.ToSerie());
      return NoContent();
    }

    // DELETE api/<SerieController>/5
    [HttpDelete, Route("Delete/{id}")]
    public IActionResult Delete(int id) {
      _repositorio.Excluir(id);
      return NoContent();
    }
  }
}
