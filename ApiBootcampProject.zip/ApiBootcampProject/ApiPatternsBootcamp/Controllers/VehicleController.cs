﻿using LocalizaFrotas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiPatternsBootcamp.Controllers {

  [Route("api/v1/[controller]")]
  [ApiController]
  public class VehicleController : ControllerBase {
    private readonly IVehicleRepository _vehicleRepositoy;

    public VehicleController(IVehicleRepository vehicleRepositoy) {
      this._vehicleRepositoy = vehicleRepositoy;
    }

    [HttpGet]
    public IActionResult Get() => Ok(_vehicleRepositoy.GetAllVehicles()); //get simplified using lambda
    
    [HttpGet("{id}")]
    public IActionResult Get(Guid id) {
      var vehicle = _vehicleRepositoy.GetById(id);
      if(vehicle == null) {
        return NotFound("Sorry, vehicle not found!");
      }
      return Ok(vehicle);
    }

    /* IMPORTANT!
     * The annotation "FROM BODY" must be used correctly stating that the information will come from the body during the httppost request
     */
    [HttpPost]
    public IActionResult Post([FromBody] Vehicle vehicle) {
      _vehicleRepositoy.Add(vehicle);
      return CreatedAtAction(nameof(Get), new { id = vehicle.Id}, vehicle); // uses the get already exist method to return a value after creating it with POST
    }

    [HttpPut("{id}")]
    public IActionResult Put(Guid id, [FromBody]Vehicle vehicle) {
      _vehicleRepositoy.Update(vehicle);
      return NoContent();
    }

    [HttpDelete]
    public IActionResult Delete(Guid id) {
      var vehicle = _vehicleRepositoy.GetById(id);
      if(vehicle == null) {
        return NotFound();
      }
      _vehicleRepositoy.Delete(vehicle);
      return NoContent();
    }
  }
}
