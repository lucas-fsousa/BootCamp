﻿using System;
using System.Collections.Generic;


namespace LocalizaFrotas {
  public interface IVehicleRepository {

    public Vehicle GetById(Guid id);

    public IEnumerable<Vehicle> GetAllVehicles();

    public void Add(Vehicle vehicle);

    public void Delete(Vehicle id);

    public void Update(Vehicle vehicle);

  }
}
