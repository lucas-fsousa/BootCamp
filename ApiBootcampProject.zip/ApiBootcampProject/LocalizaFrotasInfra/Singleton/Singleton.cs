﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalizaFrotasInfra.Singleton {
  public sealed class Singleton {
    // whenever the class is instantiated, it will receive a unique identifier.
    public Guid Id { get; } = Guid.NewGuid();

    private static Singleton instance = null;

    private Singleton() { } // define private constructor to prevent new instances of the class

    public static Singleton Instance {
      get { 
        if(instance == null) {
          instance = new Singleton();
        }
        return instance;
      }
    }


  }
}
