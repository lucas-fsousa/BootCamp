﻿using LocalizaFrotas;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LocalizaFrotasInfra.Repository {

  /*This implementation is simulating a database using memory.
   *The actions performed will add, update and delete items that exist in memory just to simulate a database
   */
  public class InMemoryRepository : IVehicleRepository {
    private readonly IList<Vehicle> entities = new List<Vehicle>();
    public void Add(Vehicle vehicle) => entities.Add(vehicle); // simplified with lambda

    public void Delete(Vehicle vehicle) => entities.Remove(vehicle); // simplified with lambda

    public IEnumerable<Vehicle> GetAllVehicles() => entities.ToList(); // simplified with lambda

    public Vehicle GetById(Guid id) => entities.SingleOrDefault(c => c.Id == id); // simplified with lambda

    public void Update(Vehicle vehicle) {
      entities.Remove(GetById(vehicle.Id));
      entities.Add(vehicle);
    }
  }
}
