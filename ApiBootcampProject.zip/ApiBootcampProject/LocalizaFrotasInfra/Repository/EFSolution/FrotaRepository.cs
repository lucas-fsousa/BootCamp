﻿using LocalizaFrotas;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalizaFrotasInfra.Repository.EFSolution {
  public class FrotaRepository : IVehicleRepository {
    private readonly FrotaContext _context;

    public FrotaRepository(FrotaContext frotaContext) => this._context = frotaContext;

    public void Add(Vehicle vehicle) {
      _context.Vehicles.Add(vehicle);
      _context.SaveChanges();
    }

    public void Delete(Vehicle id) {
      _context.Vehicles.Remove(id);
      _context.SaveChanges();
    }

    public IEnumerable<Vehicle> GetAllVehicles() => _context.Vehicles.ToListAsync().Result;

    public Vehicle GetById(Guid id) => _context.Vehicles.SingleOrDefaultAsync().Result;

    public void Update(Vehicle vehicle) {
      _context.Entry(vehicle).State = EntityState.Modified;
      _context.SaveChanges();
    }
  }
}
