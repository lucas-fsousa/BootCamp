﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalizaFrotasInfra.Facade {
  public class DetranOptions {

    public Guid Id { get; } = Guid.NewGuid();

    public string UrlBase { get; set; }

    public string UriSurvey { get; set; }

    public int DaysQuantityForPayment { get; set; }

  }
}
