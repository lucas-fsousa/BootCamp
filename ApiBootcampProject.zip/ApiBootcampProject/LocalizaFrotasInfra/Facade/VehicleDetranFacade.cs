﻿using LocalizaFrotas;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalizaFrotasInfra.Facade {
  public class VehicleDetranFacade : IDetranVehicle {
    private readonly IOptionsMonitor<DetranOptions> _optionsMonitor;

    public VehicleDetranFacade(IOptionsMonitor<DetranOptions> optionsMonitor) {
      this._optionsMonitor = optionsMonitor;
    }

    public Task ScheduleInspection(Guid vehicle) {
      throw new NotImplementedException();
    }
  }
}
