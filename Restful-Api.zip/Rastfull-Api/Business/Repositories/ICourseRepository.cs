﻿using ApiBootcamp.Business.Entities;
using System.Collections.Generic;

namespace ApiBootcamp.Business.Repositories {
  public interface ICourseRepository {
    void Add(Course course);
    void Commit();
    IList<Course> GetCoursesByUserId(int userId);
  }
}
