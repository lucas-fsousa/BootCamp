﻿using ApiBootcamp.Business.Entities;
using ApiBootcamp.Infraestructure.Data.Mappings;
using Microsoft.EntityFrameworkCore;

namespace ApiBootcamp.Infraestructure.Data {
  public class CourseContext: DbContext {
    public CourseContext(DbContextOptions<CourseContext> options) :base(options) {

    }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder) {
      modelBuilder.ApplyConfiguration(new CourseMappings());
      modelBuilder.ApplyConfiguration(new UserMappings());
      base.OnModelCreating(modelBuilder);
    }

    public DbSet<User> User { get; set; }

    public DbSet<Course> Course { get; set; }
  }
}
