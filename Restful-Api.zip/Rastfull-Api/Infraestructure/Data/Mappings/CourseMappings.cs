﻿using ApiBootcamp.Business.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace ApiBootcamp.Infraestructure.Data.Mappings {

  /* The interface to be implemented will deal with the configuration of the database.
   * Using the ORM ENTITY FRAMEWORK
   * It is mapping the Course entity class in Business/Entities */

  public class CourseMappings : IEntityTypeConfiguration<Course> {
    public void Configure(EntityTypeBuilder<Course> builder) {

      builder.ToTable("TB_COURSE"); // Define the table name
      builder.HasKey(p => p.Id); // Primary key configuration
      builder.Property(p => p.Id).ValueGeneratedOnAdd(); // Configure the Identity table count
      builder.Property(p => p.Description); // Default column name as per model class
      builder.Property(p => p.Name); // Default column name as per model class
      builder.HasOne(p => p.User).WithMany().HasForeignKey(fk => fk.UserId); // Define a Foreign Key of class

    }
  }
}
