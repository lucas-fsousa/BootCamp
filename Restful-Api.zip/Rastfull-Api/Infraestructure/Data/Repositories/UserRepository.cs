﻿using ApiBootcamp.Business.Entities;
using ApiBootcamp.Business.Repositories;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiBootcamp.Infraestructure.Data.Repositories {
  public class UserRepository : IUserRepository {

    private readonly CourseContext _context;

    public UserRepository(CourseContext context) {
      this._context = context;
    }

    public void Add(User user) {
      this._context.User.Add(user);
    }

    public void Commit() {
      this._context.SaveChanges();
    }

    public User GetUser(string login) {
      return this._context.User.FirstOrDefault(u => u.Login == login);
    }
  }
}
