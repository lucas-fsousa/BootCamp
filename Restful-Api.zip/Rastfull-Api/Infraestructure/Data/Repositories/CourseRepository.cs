﻿using ApiBootcamp.Business.Entities;
using ApiBootcamp.Business.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiBootcamp.Infraestructure.Data.Repositories {
  public class CourseRepository: ICourseRepository {
    private readonly CourseContext _context;

    public CourseRepository(CourseContext context) {
      _context = context;
    }

    public void Add(Course course) {
      _context.Course.Add(course);
    }

    public void Commit() {
      _context.SaveChanges();
    }

    public IList<Course> GetCoursesByUserId(int userId) {
      // Executa um select no banco de dados retornando uma lista de informações baseadas na definição do where. 
      return _context.Course.Include(i => i.User).Where(w => w.UserId == userId).ToList();
    }
  }
}
