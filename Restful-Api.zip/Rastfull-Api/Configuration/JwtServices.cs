﻿using ApiBootcamp.Models.Users;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ApiBootcamp.Configuration {
  public class JwtServices : IAuthenticationServices {
    private readonly IConfiguration _configuration;
    public JwtServices(IConfiguration configuration) {
      _configuration = configuration;
    }

    public string GetToken(UserViewModelOutput userViewModelOutput) {
      var secret = Encoding.ASCII.GetBytes(_configuration.GetSection("JwtConfigurations:Secret").Value);
      var symmetricSecutiryKey = new SymmetricSecurityKey(secret);
      var secutiryKeyTokenDescriptor = new SecurityTokenDescriptor {
        Subject = new ClaimsIdentity(new Claim[] {
          new Claim(ClaimTypes.NameIdentifier, userViewModelOutput.Id.ToString()),
          new Claim(ClaimTypes.Name, userViewModelOutput.Login.ToString()),
          new Claim(ClaimTypes.Email, userViewModelOutput.Email.ToString())
        }),
        Expires = DateTime.UtcNow.AddDays(1),
        SigningCredentials = new SigningCredentials(symmetricSecutiryKey, SecurityAlgorithms.HmacSha256Signature)
      };

      var jwtSecutiryTokenHandler = new JwtSecurityTokenHandler();
      var tokenGenerated = jwtSecutiryTokenHandler.CreateToken(secutiryKeyTokenDescriptor);
      var token = jwtSecutiryTokenHandler.WriteToken(tokenGenerated);
      return token;
    }
  }
}
