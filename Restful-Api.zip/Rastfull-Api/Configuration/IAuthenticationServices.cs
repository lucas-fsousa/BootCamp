﻿using ApiBootcamp.Models.Users;

namespace ApiBootcamp.Configuration {
  public interface IAuthenticationServices {
    string GetToken(UserViewModelOutput userViewModelOutput);
  }
}
