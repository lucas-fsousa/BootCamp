﻿using ApiBootcamp.Infraestructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace ApiBootcamp.Configuration {
  public class DbFactoryContext: IDesignTimeDbContextFactory<CourseContext> {
    
    public CourseContext CreateDbContext(string[] args) {
      var optionsBuilder = new DbContextOptionsBuilder<CourseContext>();
      optionsBuilder.UseSqlServer("Data Source=Lucas;Initial Catalog=BootcampApibase;Integrated Security=True");
      CourseContext context = new CourseContext(optionsBuilder.Options);
      return context;
    }
  }
}
