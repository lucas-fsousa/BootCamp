﻿using ApiBootcamp.Models.Users;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Linq;

namespace ApiBootcamp.Filters {
  public class ValidationModelFilter: ActionFilterAttribute {
    public override void OnActionExecuting(ActionExecutingContext context) {
      if(!context.ModelState.IsValid) {
        var validate = new ValidationOutputModel(context.ModelState.SelectMany(sm => sm.Value.Errors).Select(s => s.ErrorMessage));
        context.Result = new BadRequestObjectResult(validate);
      }
    }
  }
}
