﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiBootcamp.Models.Courses {
  public class CourseViewModelInput {
    public string Name { get; set; }
    public string Description { get; set; }
  }
}
