﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiBootcamp.Models.Courses {
  public class CourseViewModelOutput {

    public string Login { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
  }
}
