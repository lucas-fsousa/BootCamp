﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ApiBootcamp.Models.Users {
  public class LoginViewModelinput {

    [Required(ErrorMessage = "The login field is mandatory.Please fill in correctly.")]
    public string Login { get; set; }

    [DataType(DataType.Password)]
    [Required(ErrorMessage = "The password field is mandatory.Please fill in correctly.")]
    public string Password { get; set; }

  }
}
