﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiBootcamp.Models.Users {
  public class ValidationOutputModel {

    public IEnumerable<string> Errors { get; private set; }

    public ValidationOutputModel(IEnumerable<string> errors) {
      Errors = errors;
    }
  }
}
