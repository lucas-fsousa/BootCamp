﻿using ApiBootcamp.Business.Entities;
using ApiBootcamp.Business.Repositories;
using ApiBootcamp.Configuration;
using ApiBootcamp.Filters;
using ApiBootcamp.Models.Error;
using ApiBootcamp.Models.Users;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System;

namespace ApiBootcamp.Controllers {

  [Route("api/v1/user")]
  [ApiController]
  public class UserController : Controller {

    private readonly IUserRepository _userRepository;
    
    private readonly IAuthenticationServices _authenticationServices;

    public UserController(IUserRepository userRepository, IAuthenticationServices authenticationService) {
      _userRepository = userRepository;
      _authenticationServices = authenticationService;
    }

    [HttpPost] // Http post verb
    [Route("login")] // route setup
    [ValidationModelFilter] // Custom filter to avoid code duplication
    [SwaggerResponse(statusCode: 200, "Successful request", typeof(LoginViewModelinput))] // HTTP callback annotation with swegger
    [SwaggerResponse(statusCode: 400, "There are required fields", typeof(ValidationOutputModel))] // HTTP callback annotation with swegger
    [SwaggerResponse(statusCode: 500, "Internal error", typeof(GenericErrorModel))] // HTTP callback annotation with swegger
    public IActionResult Login(LoginViewModelinput loginViewModelinput) {
      /*
       * Model replaced. Check Filters folder
       * if(!ModelState.IsValid) {
       *  return BadRequest();
       * }
       */

      //Fake login
      //var userViewModelOutput = new UserViewModelOutput() {
      //  Id = 1,
      //  Login = "Jorge",
      //  Email = "jorgin@hotmail.com",
      //};


      User user = _userRepository.GetUser(loginViewModelinput.Login);
      if(user == null) {
        return BadRequest("Unexpected error while trying to accessr");
      }
      
      
      var userViewModelOutput = new UserViewModelOutput() {
        Login = loginViewModelinput.Login,
        Email = user.Email,
        Id = user.Id
      };

      var token = _authenticationServices.GetToken(userViewModelOutput);
      return Ok(new { 
        Token = token, User = userViewModelOutput
      }); // returns the status 200  - Ok
    }

    [HttpPost]
    [Route("register")]
    [ValidationModelFilter] // Custom filter to avoid code duplication
    [SwaggerResponse(statusCode: 200, "Successful request", typeof(LoginViewModelinput))] // HTTP callback annotation with swegger
    [SwaggerResponse(statusCode: 400, "There are required fields", typeof(ValidationOutputModel))] // HTTP callback annotation with swegger
    [SwaggerResponse(statusCode: 500, "Internal error", typeof(GenericErrorModel))] // HTTP callback annotation with swegger
    [ValidationModelFilter] // Custom filter to avoid code duplication
    public IActionResult Register(RegisterViewModelinput registerViewModelinput) {
      /*
       * Model replaced. Check Filters folder
       * if(!ModelState.IsValid) {
       *  return BadRequest();
       * }
       */
      try {
        //var optionsBuilder = new DbContextOptionsBuilder<CourseContext>();
        //optionsBuilder.UseSqlServer("Data Source=Lucas;Initial Catalog=BootcampApibase;Integrated Security=True");
        //CourseContext context = new CourseContext(optionsBuilder.Options);

        //var migrationsPending = context.Database.GetPendingMigrations();
        //if(migrationsPending.Count() > 0) {
        //  context.Database.Migrate();
        //}

        var user = new User();
        user.Login = registerViewModelinput.Login;
        user.Password = registerViewModelinput.Password;
        user.Email = registerViewModelinput.Email;
        _userRepository.Add(user); // Interface References
        _userRepository.Commit(); // Interface References

        return Created("", registerViewModelinput); // returns the status 201 - Created
      } catch(Exception) {

        throw;
      }
    }
  }
}
