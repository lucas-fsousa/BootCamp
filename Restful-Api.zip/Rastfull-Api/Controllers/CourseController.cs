﻿using ApiBootcamp.Business.Entities;
using ApiBootcamp.Business.Repositories;
using ApiBootcamp.Models.Courses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ApiBootcamp.Controllers {
  
  [Route("api/v1/courses")]
  [ApiController]
  [Authorize]
  public class CourseController : Controller {

    private readonly ICourseRepository _courseRepository;
    public CourseController(ICourseRepository courseRepository) {
      _courseRepository = courseRepository;
    }

    [HttpPost]
    [Route("post")]
    [SwaggerResponse(statusCode: 201, description: "Success in registering a course")]
    [SwaggerResponse(statusCode: 401, description: "not authorized")]
    public async Task<IActionResult> Post(CourseViewModelInput courseViewModelInput) {
      var id = int.Parse(User.FindFirst(c => c.Type == ClaimTypes.NameIdentifier)?.Value);
      Course course = new Course();

      course.Name = courseViewModelInput.Name;
      course.Description = courseViewModelInput.Description;
      course.Description = courseViewModelInput.Description;
      course.UserId = id;
      _courseRepository.Add(course);
      _courseRepository.Commit();

      return Created("", courseViewModelInput);
    }


    [HttpGet]
    [Route("get")]
    [SwaggerResponse(statusCode: 200, description: "Successful requesting a result")]
    [SwaggerResponse(statusCode: 401, description: "not authorized")]
    public async Task<IActionResult> Get([FromQuery]CourseViewModelInput courseViewModelInput) {
      var userId = int.Parse(User.FindFirst(c => c.Type == ClaimTypes.NameIdentifier)?.Value);
      var courses = _courseRepository.GetCoursesByUserId(userId).Select(s => new CourseViewModelOutput() { 
        Login = s.User.Login,
        Description = s.Description,
        Name = s.Name
      });
      
      
      return Ok(courses);
    }
  }
}
