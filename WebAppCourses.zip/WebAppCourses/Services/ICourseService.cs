﻿using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebAppCourses.Models.Course;

namespace WebAppCourses.Services {
  public interface ICourseService {

    [Post("/api/v1/cursos")]
    [Headers("Authorization: Bearer")]
    public Task<CourseRegisterViewModelOutput> Register(CourseRegisterViewModelInput courseRegisterViewModelInput);

    [Get("/api/v1/cursos")]
    [Headers("Authorization: Bearer")]
    public Task<List<ListCourseViewModelOutput>> GetAllCourses();
  }
}
