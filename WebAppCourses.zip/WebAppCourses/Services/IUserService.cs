﻿using Refit;
using System.Threading.Tasks;
using WebAppCourses.Models.User;

namespace WebAppCourses.Services {
  public interface IUserService {

    [Post("/api/v1/usuario/registrar")]
    public Task<UserRegisterViewModelInput> Register(UserRegisterViewModelInput userRegisterViewModelInput);

    [Post("/api/v1/usuario/logar")]
    public Task<LoginViewModelOutput> Login(LoginViewModelInput loginViewModelInput);
  }
}
