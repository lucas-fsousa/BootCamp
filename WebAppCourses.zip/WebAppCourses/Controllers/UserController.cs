﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Refit;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebAppCourses.Models.User;
using WebAppCourses.Services;

namespace WebAppCourses.Controllers {
  public class UserController : Controller {

    private readonly IUserService _userService;
    public UserController(IUserService userService) {
      _userService = userService;
    }

    [HttpGet]
    public IActionResult Login() {
      return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModelInput loginViewModelInput) {
      try {
        var user = await _userService.Login(loginViewModelInput);

        //User security on the front end using cookies and temporarily storing authentication data in the browser's memory
        var claims = new List<Claim> { 
          new Claim(ClaimTypes.NameIdentifier, user.User.Id.ToString()),
          new Claim(ClaimTypes.Name, user.User.Login),
          new Claim(ClaimTypes.Email, user.User.Email),
          new Claim("token", user.Token),
        };
        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

        // Definition of authentication validity time.
        var authProperties = new AuthenticationProperties {
          ExpiresUtc = new DateTimeOffset(DateTime.UtcNow.AddHours(12))
        };
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);

        ModelState.AddModelError("", $"The user {user.User.Login} has successfully authenticated.");
      } catch(ApiException) {
        ModelState.AddModelError("", "fail - API");
      } catch(Exception) {
        ModelState.AddModelError("", "fail - GENERIC");
      }

      return View();
    }

    [HttpGet]
    public IActionResult Register() {
      return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(UserRegisterViewModelInput registerViewModelInput) {
      try {
        var user = await _userService.Register(registerViewModelInput);
        ModelState.AddModelError("", $"Registration performed successfully for {user.Login}");
      } catch(ApiException) {
        ModelState.AddModelError("", "Registration was not completed successfully. Check the parameters and try again.");
      } catch(Exception genericException) {
        ModelState.AddModelError("", genericException.Message);
      }
      return View();
    }

    public IActionResult GoToLogoff() {
      return View();
    }

    [HttpPost]
    public async Task Logoff() {
      await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
      Response.Redirect("/User/Login");
    }

    //[HttpPost]
    //public IActionResult Register(UserRegisterViewModelInput registerViewModelInput) {
    //  try {
    //    _userService.Register(registerViewModelInput);

    //    ///*This is a development environment only setting.
    //    // * The purpose of this setting is to ignore all HTTPS security policy objects to avoid connection errors when interacting with the API backend
    //    // */
    //    //var clientHanlderConfig = new HttpClientHandler();
    //    //clientHanlderConfig.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
    //    //// END CONFIG HTTPS

    //    //var httpClient = new HttpClient(clientHanlderConfig);
    //    //httpClient.BaseAddress = new Uri("https://localhost:5001");

    //    //var jsonInput = JsonConvert.SerializeObject(registerViewModelInput);

    //    //var httpContent = new StringContent(jsonInput, Encoding.UTF8, "application/json");

    //    //var httpPost = httpClient.PostAsync("/api/v1/usuario/registrar", httpContent).GetAwaiter().GetResult();

    //    //if(httpPost.StatusCode == HttpStatusCode.Created) {
    //    //  ModelState.AddModelError("", "Registration performed successfully!");
    //    //} else {
    //    //  ModelState.AddModelError("", "Registration was not completed successfully. Check the parameters and try again.");
    //    //}
    //  } catch(Exception ex) {
    //    string a = ex.ToString();
    //  }
    //  return View();
    //}

  }
}
