﻿using Microsoft.AspNetCore.Mvc;
using Refit;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebAppCourses.Models.Course;
using WebAppCourses.Services;
using System.Net;

namespace WebAppCourses.Controllers {

  [Microsoft.AspNetCore.Authorization.Authorize]
  public class CourseController : Controller {

    private readonly ICourseService _courseService;
    public CourseController(ICourseService courseService) {
      _courseService = courseService;
    }

    [HttpGet]
    public IActionResult Register() {
      return View();
    }

    [HttpPost]
    [Microsoft.AspNetCore.Authorization.Authorize]
    public async Task<IActionResult> Register(CourseRegisterViewModelInput courseRegisteViewModelInput) {
      try {
        var course = await _courseService.Register(courseRegisteViewModelInput);
        ModelState.AddModelError("", $"The course {course.Name} has successfully registered.");
      } catch(ApiException ex) {
        ModelState.AddModelError("", ex.Message);
      }
      return View();
    }

    [HttpGet]
    [Microsoft.AspNetCore.Authorization.Authorize]
    public async Task<IActionResult> ListCourses() {
      try {
        var courses = await _courseService.GetAllCourses();
        return View(courses);
      } catch(ApiException ex) {
        ModelState.AddModelError("", ex.Message);
      } catch(Exception ex) {
        ModelState.AddModelError("", ex.Message);
      }
      return View();
    }
  }
}
