﻿using System.ComponentModel.DataAnnotations;

namespace WebAppCourses.Models.User {
  public class UserRegisterViewModelInput {

    [Required(ErrorMessage = "Insert a valid login!")]
    public string Login { get; set; }

    [Required(ErrorMessage = "Inser a valid email")]
    [DataType(DataType.EmailAddress)]
    [EmailAddress]
    public string Email { get; set; }

    [Required]
    [DataType(DataType.Password)]
    [StringLength(8, ErrorMessage = "Password must be at least 8 characters.")]
    public string Password { get; set; }
  }
}
