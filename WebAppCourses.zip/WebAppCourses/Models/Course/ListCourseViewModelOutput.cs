﻿namespace WebAppCourses.Models.Course {
  public class ListCourseViewModelOutput {
    public string Name { get; set; }
    public string Description { get; set; }
    public string Login { get; set; }
  }
}
