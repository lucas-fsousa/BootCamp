﻿using System.ComponentModel.DataAnnotations;
namespace WebAppCourses.Models.Course {
  public class CourseRegisterViewModelOutput {

    public string Name { get; set; }

    public string Description { get; set; }

    public string Login { get; set; }
  }
}
