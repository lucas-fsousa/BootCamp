﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace WebAppCourses.Handlers {
  public class BearerTokenMessageHandler: DelegatingHandler {
    private readonly IHttpContextAccessor _httpContextAcessor;

    public BearerTokenMessageHandler(IHttpContextAccessor httpContextAccessor) {
      _httpContextAcessor = httpContextAccessor;
    }

    /*The method will be overwritten and will start intercepting the request so that it is possible to add the User Token to the header.
     * Then the base class will be returned so that the request continues as expected.*/
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancelToken) {
      try {
        if(request?.Headers?.Authorization != null) {
          var token = _httpContextAcessor.HttpContext.User.FindFirst("token").Value;
          request.Headers.Authorization = new AuthenticationHeaderValue(request.Headers.Authorization.Scheme, token);
        }
      } catch(Exception ex) {
        string a = "ex";
      }
      return await base.SendAsync(request, cancelToken);
    }
  }
}
